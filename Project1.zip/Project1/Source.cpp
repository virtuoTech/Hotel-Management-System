#include<iostream>
#include<fstream>
#include <string>
#include <Windows.h>
#include<conio.h>
using namespace std;

//ADMIN//

struct admin
{
	string name;
	string ID;
	string address;
	string salary;
	string phone;
};

admin wrk[30];
int tot = 0;


void emp_indata(){

	int user = 0;
	cout << "How many employee's data do you want to enter??" << endl;
	cout << "enter:";
	cin >> user;

	for (int i = tot; i < tot + user; i++){

		system("CLS");

		cout << "------Enter information of employee------ " << endl;
		cout << "DATA OF EMPLOYEE " << i + 1 << ": " << endl;

		//cout << "DATA OF EMPLOYEE " << i + 1 << ": " << endl;

		cout << "Enter employee name: ";
		cin.ignore();
		getline(cin, wrk[i].name);

		cout << "Enter ID: ";

		//cin.ignore(1);
		getline(cin, wrk[i].ID);
		cout << "Enter address: ";

		//cin.ignore();
		getline(cin, wrk[i].address);

		cout << "Enter contact: ";

		//cin.ignore();
		getline(cin, wrk[i].phone);

		cout << "Enter salary: ";

		//cin.ignore();
		getline(cin, wrk[i].salary);

	}

	tot = tot + user;

}
//EMPLYOYEE_DATA//
void emp_show(){
	ofstream out("ADMIN.txt", ios::app);
	if (tot != 0){

		for (int i = 0; i < tot; i++){
			cout << endl << endl;
			cout << "----------Data of employee " << i + 1 << "----------" << endl;
			cout << "DATA OF EMPLOYEE " << i + 1 << ": " << endl;
			out << "DATA OF EMPLOYEE " << i + 1 << ": " << endl;

			cout << "Name: " << wrk[i].name << endl;
			out << "Name: " << wrk[i].name << endl;

			cout << "ID: " << wrk[i].ID << endl;
			out << "ID: " << wrk[i].ID << endl;

			cout << "Address: " << wrk[i].address << endl;
			out << "Address: " << wrk[i].address << endl;

			cout << "Contact: " << wrk[i].phone << endl;
			out << "Contact: " << wrk[i].phone << endl;

			cout << "Salary: " << wrk[i].salary << "Rs" << endl;
			out << "Salary: " << wrk[i].salary << "Rs" << endl;
			cout << "------------------------------------------------------" << endl;
			out << "------------------------------------------------------" << endl;

		}
	}
	else{
		cout << "No data is entered!!" << endl;
	}
	out.close();
}


//SEARCHING_OF_EMPLOYEE//
void emp_search(){
	ofstream out("search.txt", ios::app);
	if (tot != 0){

		string Id;

		cout << "Enter ID of employee which you want to search: ";
		out << "Enter ID of employee which you want to search: ";
		cin >> Id;
		out << Id;
		for (int i = 0; i < tot; i++){

			if (wrk[i].ID == Id){

				
				cout << "-----------Data of employee-----------" << endl;
				out << "-----------Data of employee-----------" << endl;

				cout << "DATA OF EMPLOYEE " << i + 1 << ":-" << endl;
				cout << "DATA OF EMPLOYEE " << i + 1 << ":-" << endl;

				cout << "Name: " << wrk[i].name << endl;
				out << "Name: " << wrk[i].name << endl;

				cout << "ID: " << wrk[i].ID << endl;
				out << "ID: " << wrk[i].ID << endl;

				cout << "Address: " << wrk[i].address << endl;
				out << "Address: " << wrk[i].address << endl;

				cout << "Contact: " << wrk[i].phone << endl;
				out << "Contact: " << wrk[i].phone << endl;

				cout << "Salary: " << wrk[i].salary << "Rs" << endl;
				 out << "Salary: " << wrk[i].salary << "Rs" << endl;

				 out << "-------------------------------------" << endl;
				 out.close();
				 break;


			}

			if (i == tot - 1){

				cout << "------No record found------" << endl;

			}

		}

	}
	else{

		cout << "Nothing entered!!" << endl;

	}

}

//RECEPTIONIST_DATA_HANDLING//
void Employee(){
	string username, pass;

	cout << "----------------SIGN UP--------------- " << endl;
	cout << "User ID : ";
	cin.ignore();
	getline(cin, username);
	cout << "Password : ";
	getline(cin, pass);

	for (int i = 0; i < 8; i++)
	{
		cout << ".";
		Sleep(300);

	}
	cout << endl;
	cout << "Singed up succesfully" << endl;
	Sleep(800);
	system("CLS");
up:
	string user0, pass0;

	cout << "*LOGIN*" << endl;
	cout << "Username: ";
	//cin.ignore();
	getline(cin, user0);
	cout << "Password: ";
	getline(cin, pass0);
	if (user0 == username && pass0 == pass)
	{
		system("CLS");
		char ch;
		while (1){
			cout << "-----------------" << endl << endl;
			cout << "PRESS-1 To Enter data" << endl;
			cout << "PRESS-2 To Show data" << endl;
			cout << "PRESS-3 To Search data" << endl;
			cout << "PRESS-4 To Logout" << endl;
			cout << "PRESS-5 To Exit" << endl;
			cout << "Enter your choice:";
			cin >> ch;
			switch (ch){
			case '1':
				emp_indata();
				break;
			case '2':
				emp_show();
				break;
			case '3':
				emp_search();
				break;
			case '4':
				goto up;
			case '5':
				exit(0);
			default:
				cout << "INCORRECT" << endl;
				break;
			}
		}
	}
	else if (user0 != username)
	{
		cout << "Credentials are incorrect" << endl;
		goto up;
	}
	else if (pass0 != pass)
	{
		cout << "Credentials are incorrect" << endl;
		goto up;
	}
}
//RECEPTION//

void Room_booking(){
	ofstream show("room_booking.txt", ios::app);
book:
	system("CLS");
	int n, R_cost;
	int Nrooms = 35;
	int roombill;
	int roombill_d;

	cout << "\n*Room Booking*" << endl;
	cout << endl << endl;
	cout << "\nCost of single Room = " << "5500" << endl;
	show << "\nCost of single Room = " << "5500" << endl;
	cout << "\nTotal no of rooms : " << Nrooms << endl;
	show << "\nTotal no of rooms : " << Nrooms << endl;
	cout << "\nEnter no of rooms you want = ";
	cin >> n;
	show << "\nEnter no of rooms you want = " << n << endl;
	if ((n > 2) && (n<36))
	{
		roombill = n * 5500;
		cout << "Before discount : " << roombill << endl;
		show << "Before discount : " << roombill << endl;
		cout << endl;
		roombill_d = n * 5500 - 1500;
		cout << "As you have entered more than 2 rooms here is a dicount : " << roombill_d << endl;
		show << "As you have entered more than 2 rooms here is a dicount : " << roombill_d << endl;
		cout << "\n**ABOUT ROOMS" << endl;
		show << "\n**ABOUT ROOMS" << endl;
		cout << "\nSold rooms : " << n << endl << endl;
		show << "\nSold rooms : " << n << endl << endl;
		cout << "\nRemaining rooms : " << Nrooms - n << endl << endl;
		show << "\nRemaining rooms : " << Nrooms - n << endl << endl;

	}
	if (n <= 2)
	{
		cout << "Total Rooms cost : " << n * 5500 << endl;
		show << "Total Rooms cost : " << n * 5500 << endl;
		cout << "\n**ABOUT ROOMS*" << endl;
		show << "\n**ABOUT ROOMS*" << endl;
		cout << "\nSold rooms : " << n << endl << endl;
		show << "\nSold rooms : " << n << endl << endl;
		cout << "\nRemaining rooms : " << Nrooms - n << endl << endl;
		show << "\nRemaining rooms : " << Nrooms - n << endl << endl;
	}
	if (n > 35)
	{
		cout << "\n\n We do not have that much capacity!!!!!!" << endl;
		Sleep(800);
		goto book;
	}
	cout << "\nABOUT ROOMS" << endl;
	show << "\nABOUT ROOMS" << endl;
	cout << "\nSold rooms : " << n << endl << endl;
	show << "\nSold rooms : " << n << endl << endl;
	cout << "\nRemaining rooms : " << Nrooms - n << endl << endl;
	show << "\nRemaining rooms : " << Nrooms - n << endl << endl;
	for (int i = 0; i < 8; i++)
	{
		cout << ".";
		Sleep(1000);
	}
	cout << "Rooms Booked";
	show << "Rooms Booked";
	Sleep(800);

	system("CLS");
}


//FORM//
void  form(){
	ofstream out("form.txt", ios::app);
	system("CLS");
	string  Fullname;
	//string lname;
	//string nguest;
	string email;
	string phone;
	cout << "\n\nCHECK IN " << endl;
	cout << "\nEnter Your Fullname :";
	out << "\n*INFORMATION*" << endl;
	cin.ignore();
	getline(cin, Fullname);
	out << "\nName : " << Fullname << endl;

	//cout << "Enter last Name :";
	//cin >> lname;

	cout << "\nEnter Email :";
	getline(cin, email);
	out << "\nEmail : " << email << endl;

	cout << "\nEnter Phone no :";

	getline(cin, phone);
	out << "\nPhone no :" << phone << endl;
	out.close();
	cout << "-----------------GUEST INFORMATION-----------------" << endl;
	cout << "\n\nName : " << Fullname << endl;
	cout << "\n\nEmail : " << email << endl;
	cout << "\n\nPhone number : " << phone << endl;


	for (int i = 0; i < 4; i++)
	{
		cout << ".";
		Sleep(1000);

	}
	system("CLS");


}
//GUEST//

void billing(){
	ofstream out("checking.txt");
	int ch[7], briyani = 250, karhai = 1500, handi = 1800, burger = 300, pizza = 2000, naan = 60, juice = 200;
	int Quan, T_price[100], change, pay, n;
	int tb = 0, tk = 0, th = 0, tbr = 0, tp = 0, tn = 0, tj = 0, billamount = 0;
menu:;

	cout << "-------------------------------" << endl;
	cout << "NO.      MENU          PRICE" << endl;
	cout << "1   chicken biryani     250" << endl;
	cout << "2   chicken karahi     1500" << endl;
	cout << "3       handi          1800" << endl;
	cout << "4    zinger burger      300" << endl;
	cout << "5     pizza(XL)        2000" << endl;
	cout << "6     rogni naan         60" << endl;
	cout << "7     orange juice      200" << endl;

	cout << "how many dishes u want to order :";
	cin >> n;

	if (n <= 7){
		for (int i = 1; i <= n; i++)
		{
			cout << "-------------------------------" << endl;
			cout << "enter your choice: ";
			cin >> ch[i];

			if (ch[i] == 1)
			{
				cout << "-------------------------------" << endl;
				cout << "You Ordered Biryani" << endl;
				cout << "Enter the amount of quantity you want: ";
				cin >> Quan;
				out << "Briyani Quantity : " << Quan << endl;
				T_price[i] = Quan * briyani;
				tb = tb + T_price[i];
				cout << "PRICE : " << tb << endl;
				out << "Total : " << tb << endl;
				out << "----------------------" << endl;
			}

			if (ch[i] == 2)
			{
				cout << "-------------------------------" << endl;
				cout << "You Ordered CHICKEN KARAHI" << endl;
				cout << "Enter the amount of quantity you want: ";
				cin >> Quan;
				out << "KARAHI Quantity : " << Quan << endl;
				T_price[i] = Quan * karhai;
				tk = tk + T_price[i];
				cout << "PRICE : " << tk << endl;
				out << "Total : " << tk << endl;
				out << "----------------------" << endl;
			}
			if (ch[i] == 3)
			{
				cout << "-------------------------------" << endl;
				cout << "You Ordered handi" << endl;
				cout << "Enter the amount of quantity you want: ";
				cin >> Quan;
				out << "Handi Quantity : " << Quan << endl;
				T_price[i] = Quan * handi;
				th = th + T_price[i];
				cout << "PRICE : " << th << endl;
				out << "Total : " << th << endl;
				out << "----------------------" << endl;
			}
			if (ch[i] == 4)
			{
				cout << "-------------------------------" << endl;
				cout << "You Ordered burger" << endl;
				cout << "Enter the amount of quantity you want: ";
				cin >> Quan;
				out << "Burger Quantity : " << Quan << endl;
				T_price[i] = Quan * burger;
				tbr = tbr + T_price[i];
				cout << "PRICE : " << tbr << endl;
				out << "Total : " << tbr << endl;
				out << "----------------------" << endl;
			}
			if (ch[i] == 5)
			{
				cout << "-------------------------------" << endl;
				cout << "You Ordered pizza" << endl;
				cout << "Enter the amount of quantity you want: ";
				cin >> Quan;
				out << "Pizza Quantity : " << Quan << endl;
				T_price[i] = Quan * pizza;
				tp = tp + T_price[i];
				cout << "PRICE : " << tp << endl;

				out << "Total : " << tp << endl;
				out << "----------------------" << endl;
			}	if (ch[i] == 6)
			{
				cout << "-------------------------------" << endl;
				cout << "You Ordered rogni naan" << endl;
				cout << "Enter the amount of quantity you want: ";
				cin >> Quan;
				out << "Rogni Naan Quantity : " << Quan << endl;
				T_price[i] = Quan * naan;
				tn = tn + T_price[i];
				cout << "PRICE : " << tn << endl;
				out << "Total : " << tn << endl;
				out << "----------------------" << endl;
			}
			if (ch[i] == 7)
			{
				cout << "-------------------------------" << endl;
				cout << "You Ordered juice" << endl;
				cout << "Enter the amount of quantity you want: ";
				cin >> Quan;
				out << "KARAHI Juice : " << Quan << endl;
				T_price[i] = Quan * juice;
				tj = tj + T_price[i];
				cout << "PRICE : " << tj << "Rs" << endl;
				out << "Total : " << tj << endl;
				out << "----------------------" << endl;
			}

		}
		billamount = tb + tk + th + tbr + tp + tn + tj;
		cout << "-------------------------------" << endl;
		cout << "your total bill is: " << billamount << "Rs" << endl;
		cout << "-------------------------------" << endl;
		cout << "enter the amount you paid: ";

		cin >> pay;
		cout << "-------------------------------" << endl;
		out << "Amount Paid : " << pay << endl;
		change = pay - billamount;
		cout << "-------------------------------" << endl;
		cout << "your change : " << change << "Rs" << endl;
		cout << "-------------------------------" << endl;
		out << "Amount returned " << change << endl;
		cout << "ORDER PLACED;)" << endl;
		Sleep(2000);
		system("CLS");
		cout << "---------------------------------------------------------------------------------------------------------" << endl;
		cout << "****THANK YOU FOR THE ORDER****" << endl;
	}


	else{

		cout << "\n\n**CAPACITY EXCEEDED**" << endl;
		cout << "\n\n**Returning to Menu**" << endl;

		for (int i = 0; i < 5; i++)
		{
			Sleep(800);
			cout << ".";
		}
		system("CLS");

		goto menu;
	}

}



int main()
{

ag:
	cout << "----------------------------------WELCOME TO THE BELLAGIO HOTEL LOBBY----------------------------------" << endl << endl << endl;
	cout << "A PROJECT BY:" << endl;
	cout << "             ABDUL RAFAY : 02-136221-009 " << endl;
	cout << "             MUHAMMAD ALI KHAN : 02-136221-033 " << endl;
	cout << "             MUHAMMAD SHAYAN : 02-136221-018 " << endl;
	Sleep(3000);
	system("CLS");

	int ch;
main:
	cout << "WHO IS LOGGING IN :" << endl;
	cout << "FOR ADMIN  PRESS       -----1" << endl;
	cout << "FOR RECEPTIONIST PRESS ------2" << endl;
	cout << "FOR GUEST PRESS        ------3" << endl;
	cout << endl;
	cout << "Enter your choice:";
	cin >> ch;
	if (ch == 1)
	{
		Employee();
	}
	if (ch == 2)
	{
		Room_booking();
		form();
		goto main;
	}
	if (ch == 3)
	{
		billing();
	}
	else
	{
		goto ag;
	}


	system("pause");
	return 0;
}